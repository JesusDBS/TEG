from .managers_core import Manager

class ModelsManager(Manager):
    """
    Data analysis object's manager

    """
    def __init__(self):

        super(ModelsManager, self). __init__()