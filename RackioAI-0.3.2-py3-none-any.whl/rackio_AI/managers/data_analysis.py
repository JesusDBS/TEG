from .managers_core import Manager

class DataAnalysisManager(Manager):
    """
    Data analysis object's manager

    """
    def __init__(self):

        super(DataAnalysisManager, self). __init__()
